# 24 Suspects on Christmas Game

2-Buttons Game Jam Dec 2020 Contribution

AGPL v3 License, see COPYING file

# Included Foreground Image Credits

pixabay license

balloon-36286__340.webp https://cdn.pixabay.com/photo/2012/04/18/00/31/balloon-36286__340.png

mask.png https://cdn.pixabay.com/photo/2020/09/28/08/38/halloween-5609078__340.png

elfC9.png https://cdn.pixabay.com/photo/2015/12/11/07/27/elf-1087758__340.png

elfA3.png  https://cdn.pixabay.com/photo/2019/11/23/07/57/elf-4646498__340.png

elfB2.png  https://cdn.pixabay.com/photo/2015/11/25/14/46/holidays-1062228__340.png

elfC1.png https://cdn.pixabay.com/photo/2019/10/02/18/21/elf-4521669_1280.png

elfD2.png https://cdn.pixabay.com/photo/2012/04/18/03/31/elf-36756_1280.png

elfD3.png https://cdn.pixabay.com/photo/2020/07/10/16/57/christmas-5391290_1280.png

elfA4.png https://cdn.pixabay.com/photo/2019/12/13/18/49/gnome-4693644__340.png

elfA6.png https://cdn.pixabay.com/photo/2018/12/07/21/38/christmas-3862474_1280.png

elfB7.png https://cdn.pixabay.com/photo/2017/11/08/22/09/christmas-2931821_1280.png

elfC5.png https://cdn.pixabay.com/photo/2019/12/18/06/08/christmas-4703190__340.jpg


elfD6.png https://cdn.pixabay.com/photo/2019/12/05/20/19/christmas-4676049_1280.jpg


elfF6.png https://cdn.pixabay.com/photo/2020/05/22/10/34/elf-5204923_1280.png

elfG6.png https://cdn.pixabay.com/photo/2020/11/11/00/05/elf-5731228__340.png

elfF7.png https://cdn.pixabay.com/photo/2019/11/04/18/20/elf-4601789__340.png

elfH4.png https://cdn.pixabay.com/photo/2017/11/13/20/11/elf-2946674__340.png

elfH7.png https://cdn.pixabay.com/photo/2019/12/27/03/21/elf-4721604__340.png

elfI5.png https://cdn.pixabay.com/photo/2019/04/26/17/49/christmas-elf-4158158__340.png

elfI6.png https://cdn.pixabay.com/photo/2016/06/02/06/10/christmas-1430335_1280.png



elfA11.png https://cdn.pixabay.com/photo/2015/12/04/11/27/eleven-1076420__340.png

elfA12.png https://cdn.pixabay.com/photo/2019/12/14/18/58/elf-4695524__340.jpg

elfC11.png https://cdn.pixabay.com/photo/2014/12/02/10/14/eleven-553756__340.png

elfC13.png https://cdn.pixabay.com/photo/2016/03/31/18/16/boy-1294259_1280.png

elfD12.png https://cdn.pixabay.com/photo/2020/11/09/10/06/elf-5726115__340.png

elfD4.png https://cdn.pixabay.com/photo/2016/04/01/00/06/blonde-1298003_1280.png




# Included Background Image Credits

The background images are mostly public domain images, visit links to know for sure, some are Pixabay license.
(some of the images below were not used in the game, however including anyway just so I don't miss any)

- https://www.needpix.com/photo/939290/park-north-carolina-nature-travel-america-wilderness-forest-united
- https://www.needpix.com/photo/download/517549/the-outer-banks-north-carolina-ocean-building-boardwalk-free-pictures-free-photos-free-images-royalty-free
- https://www.needpix.com/photo/download/1355011/appalachia-appalachian-ash-autumn-blueridgemountains-blueridgeparkway-breathtaking-bridge-brp
- https://www.needpix.com/photo/370399/icefields-parkway-snow-scenic-mountain-alberta-canada-landscape-nature-sky
- https://www.needpix.com/photo/424842/highland-road-dd-trabzon-greens-nature-clouds-landscape-village
- https://www.needpix.com/photo/download/52079/tennessee-smoky-mountains-landscape-forest-countryside-country-nature-scenic-trees
- https://www.needpix.com/photo/491744/autumn-country-road-country-rural
- https://www.needpix.com/photo/51509/tennessee-road-countryside-fence-forest-woods-trees-field-nature
- https://www.needpix.com/photo/1022106/biltmore-house-architecture-carolina-home-mansion-asheville
-  https://www.needpix.com/photo/download/652103/front-facade-mansion-estate-home-residence-landmark-biltmore-architecture-porch
-  https://www.needpix.com/photo/1675855/cades-cove-cantilever-barn-great-smoky-mountains-national-park-forest-park-national-smoky-scenic-old
-  https://www.needpix.com/photo/1286537/nature-travel-outdoors-architecture-sky-tree-fall-mountain-landscape
-  https://www.needpix.com/photo/711099/beaches-north-carolina-ocean-landscape-nature
-  https://www.needpix.com/photo/329823/lighthouse-bodie-island-north-carolina-nc-outer-banks-seashore-obx-historic-coastal
-  https://www.needpix.com/photo/323059/country-road-fall
-  https://www.needpix.com/photo/471292/rural-road-autumn-fall-foliage-scenic-colorful-highway-landscape-countryside
-  https://www.needpix.com/photo/557354/parkway-virginia-nature-landscape-scenic-appalachian-scenery-colorful-trees
-  https://www.needpix.com/photo/1438456/coveredbridge-historic-rural-country-northcarolina-historicbridges
-  https://www.needpix.com/photo/762407/beach-atlantic-beach-landscape-coast-atlantic-coast-paling-path-sand-morgenstimmung
-  https://www.needpix.com/photo/719440/forest-path-appalachian-trail-shenandoah-national-park-virginia-usa-trees-outdoors-woods
-  https://www.needpix.com/photo/51626/cabin-home-wood-log-cabin-christmas-property-decorations-beautiful-sky
-  https://www.needpix.com/photo/51871/tennessee-smoky-mountains-landscape-smokies-mountain-forest-sky-clouds-tranquil
-  https://www.needpix.com/photo/1061543/highland-mountain-snow-winter-house-white-clouds-blue-sky
-  https://www.needpix.com/photo/116534/golf-course-field-sky
-  https://www.needpix.com/photo/716440/grand-national-golf-course-opelika-alabama-landscape-scenic-sky-clouds-hdr-golfing
-  https://www.needpix.com/photo/1265706/bridge-field-footpath-golf-course-tree-landscape-dutch-landscape-holland-blue-skies
-  https://www.needpix.com/photo/download/1115248/labor-day-golf-grass-lawn-lawnmower-nature-outdoor-golf-course-trees
-  golf-114033_1280.jpg  https://www.needpix.com/photo/79940/golf-pott-ruhr-area-golf-course-poot-golf-golf-courses-sport-green-clouds
-  field-2733501_1280.jpg  https://www.needpix.com/photo/1120104/field-golf-golf-course-nature-green-game
-  golf-course-1722112_1280.jpg  https://www.needpix.com/photo/754306/golf-course-golf-landscape-sky-green-field-rainy-free-pictures-free-photos-free-images
-  golf-course-1146819_1280.jpg  https://www.needpix.com/photo/535807/golf-course-golf-sport-green-course-grass-game-golf-course-landscape-sky
-  golf-course-1415742153JGO.jpg  https://www.needpix.com/photo/1391193/golfcourse-golf-sport-fall-season-greens-landscape-outdoors-nature
-  golf-course-346443_1280.jpg  https://www.needpix.com/photo/198863/golf-course-golf-sport-lawn-ammathi-karnataka
-  georgia-122721_1280.jpg  https://www.needpix.com/photo/82213/georgia-golf-course-lake-water-fog-sky-clouds-trees-sports
-  golf-708524_1280.jgp  https://www.needpix.com/photo/353984/golf-autumn-south-tyrol-petersberg-golf-course-landscape-leisure-sport
-  golf-787472_1280.jpg  https://www.needpix.com/photo/download/388498/golf-golf-course-green-grass-landscape-outdoor-summer-golfing-fairway
- north-carolina-1182569_1280.jpg https://www.needpix.com/photo/550399/north-carolina-nature
- fence-on-the-beach.jpg  https://www.needpix.com/photo/1328112/beach-fence-wooden-sand-sea-sky-cloudy-holiday-sun
- lighthouse-668225_1280.jpg  https://www.needpix.com/photo/329820/lighthouse-bodie-island-north-carolina-nc-outer-banks-seashore-obx-historic-coastal
- beach-652119_1280.jpg https://www.needpix.com/photo/download/320132/beach-summer-cuba-free-pictures-free-photos-free-images-royalty-free-free-illustrations
- lighthouse-3209985_1280.jpg https://www.needpix.com/photo/1267573/lighthouse-sea-cliffs-water-away-road-coast-blue-beach
- atlantic-999620_1280.jpg https://www.needpix.com/photo/download/480666/atlantic-coast-england-coastal-sea-united-kingdom-white-cliffs-cliffs-water
- beach-26016_1280.jpg https://www.needpix.com/photo/download/19568/beach-aruba-sand-beach-sea-holiday-south-sea-caribbean-lesser-antilles-abc-islands
- beach-250035_1280.jpg https://www.needpix.com/photo/149994/beach-beach-house-home-hut-beach-hut-water-sea-coast-nature
- crusie-ship.jpg https://www.needpix.com/photo/1399898/cruiseship-ship-boat-transportation-docked-moored-keywest-florida-water
- north-beach-2864467_1280.jpg  https://www.needpix.com/photo/1174589/north-beach-florida-beach-erosion-damage-hurricane-irma-destruction-beach-homes-beach-ocean
- beach-250034_1280.jpg https://www.needpix.com/photo/download/149993/beach-beach-house-home-hut-beach-hut-water-sea-coast- nature  https://pixabay.com/photos/beach-beach-house-house-hut-250034/
- beach-722973_1280.jpg https://www.needpix.com/photo/download/361413/beach-chairs-sand-summer-grayton-beach-florida-free-pictures-free-photos-free-images
- beach-2669591_1280.jpg https://www.needpix.com/photo/1090487/beach-north-sea-by-the-sea-free-pictures-free-photos-free-images-royalty-free-free-illustrations
- atlantic-2162924_1280.jpg https://www.needpix.com/photo/download/897526/atlantic-sea-ocean-beach-sand-road-coast-france-atlantic-coast-landscape
- campground-3336155_1280.jpg https://www.needpix.com/photo/1572431/campground-camp-site-camping-landscape-florida-usa-vacation-campsite-nature
- cabin-beach-2396556_1280.jpg https://pixabay.com/photos/cabin-beach-sea-holiday-2396556/
- camping-2838046_1280.jpg https://www.needpix.com/photo/1164401/camping-travel-recreational-vehicle-camper-campground-campsite-mobile-camp-park
- golf-3683340_1280.webp https://pixabay.com/photos/golf-green-field-grass-sport-3683340/
- lawn-3291164_1280.jpg  https://www.needpix.com/photo/1299776/lawn-house-driveway-suburb-entrance-hdr
- garden-930815_1280.jpg  https://www.needpix.com/photo/445689/garden-tunnel-an-ornamental-garden-the-passage-of-the-pavement-path-paving-trees-grass
- autumn-2867467_1280.jpg  https://www.needpix.com/photo/1175770/autumn-park-alley-yellow-leaves
- autumn-park-1751391_1280.jpg  https://www.needpix.com/photo/765779/autumn-park-autumn-stroll-park-leaves-listopad-yellow-leaves-golden-autumn-nature
- park-1913526_1280.jpg  https://www.needpix.com/photo/823110/park-bank-autumn-tree-park-bench-castle-park-ludwigslust-parchim-schlossgarten
- park-2144714_1280.jpg https://www.needpix.com/photo/892716/park-trees
- park-1214225_1280.jpg  https://www.needpix.com/photo/download/563470/park-foliage-trees-autumn-fall-colorful-nature-landscape-forest
- autumn-1854489_1280.jpg  https://www.needpix.com/photo/download/804203/autumn-park-landscape-foliage-road-tree-season-october-november
- fall-615402_1280.jpg  https://www.needpix.com/photo/download/303241/fall-walk-bench-park-quiet-autumn-nature-forest-lifestyle
- shipwreck-1424739_1280.jpg  https://www.needpix.com/photo/643869/shipwreck-coast-sea-beach-sky
- winter-in-the-ozarks-3581418_1280.jpg  https://www.needpix.com/photo/download/1664475/winter-in-the-ozarks-winter-snow-landscape-cold-nature-mountains-wintry-white
- train-2428725_1280.jpg  https://www.needpix.com/photo/990773/train-winter-travel-railway-snow-transport-white-landscape-nature
- snow-1649682_1280.jpg  https://www.needpix.com/photo/728781/snow-fence-winter-cold-frost-white-frozen-landscape-horizon
- winter-2023593_1280.jpg  https://www.needpix.com/photo/852912/winter-wonderland-snow-nature-light-cold-outdoor-season-sky
- ice-castle-3252243_1280.jpg  https://www.needpix.com/photo/1283561/ice-castle-winter-yellowknife-castle-ice-snow
- snowman-1920667_1280.jpg  https://www.needpix.com/photo/824864/snowman-winter-snow-trees-snowfall-cold-white
- japan-2333500_1280.jpg  https://www.needpix.com/photo/947562/japan-evening-stay-the-festival-of-lights-free-pictures-free-photos-free-images-royalty-free
- christmas-3009490_1280.jpg  https://www.needpix.com/photo/download/1212706/christmas-nativity-scene-winter-josef-maria-crib-stall-jesus-snow
- wintry-1955936_1280.jpg  https://www.needpix.com/photo/833418/wintry-snowfield-snow-landscape-snow-storm-sinking-in-sun-clouds-hut-tree-winter
- the-scenery-2448129_1280.jpg  https://www.needpix.com/photo/998802/the-scenery-santa-claus-village-nordic
- 1-1264443337K484.jpg  https://www.needpix.com/photo/1309088/cold-ice-landscape-crossroad-nature-road-rural-snow-street
- christmas-house-1901846_1280.jpg  https://www.needpix.com/photo/819134/christmas-house-snowy-neighborhood-snow-winter-neighborhood-house-christmas-cold-season


